 "use client";
import { useEffect,useState } from "react";
import { createClient } from "@/lib/supabase/client";
type Bank={id:string;account_name:string;bank_name:string|null};
export default function PaymentsPage(){
 const [direction,setDirection]=useState("in"),[method,setMethod]=useState("upi"),[amount,setAmount]=useState(""),[date,setDate]=useState(new Date().toISOString().slice(0,10));
 const [clientId,setClientId]=useState(""),[vendorId,setVendorId]=useState(""),[bankId,setBankId]=useState(""),[counter,setCounter]=useState(""),[reference,setReference]=useState(""),[notes,setNotes]=useState("");
 const [banks,setBanks]=useState<Bank[]>([]),[busy,setBusy]=useState(false),[message,setMessage]=useState(""),[error,setError]=useState("");
 useEffect(()=>{const s=createClient();s.from("bank_accounts").select("id,account_name,bank_name").eq("active",true).then(({data})=>setBanks((data??[]) as Bank[]));},[]);
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage("");setError("");
 try{const s=createClient();const {data,error}=await s.rpc("record_ledger_payment",{p_direction:direction,p_method:method,p_amount:Number(amount),p_payment_date:date,p_client_id:clientId||null,p_vendor_id:vendorId||null,p_project_id:null,p_bank_account_id:method==="cash"?null:(bankId||null),p_reference:reference||null,p_notes:notes||null,p_counter_account_code:direction==="out"?(counter||null):null,p_allocations:[]});
 if(error)throw error;const result=Array.isArray(data)?data[0]:data;setMessage(`Saved receipt ${result?.receipt_number??result?.receipt??"successfully"}. Journal entry created.`);setAmount("");setReference("");setNotes("");
 }catch(err){setError(err instanceof Error?err.message:"Unable to record payment");}finally{setBusy(false);}}
 return <main className="content"><div className="eyebrow">Finance</div><h1 className="heading">Payments & receipts</h1><p className="sub">Record money received or paid. This is a manual ledger entry, not a payment gateway.</p>
 <div className="notice">Only record a receipt after confirming funds have actually arrived. This form does not transfer or verify money.</div>
 <form className="panel" onSubmit={submit}><div className="formgrid">
 <div className="field"><label>Transaction type</label><select value={direction} onChange={e=>setDirection(e.target.value)}><option value="in">Money received</option><option value="out">Money paid</option></select></div>
 <div className="field"><label>Payment method</label><select value={method} onChange={e=>setMethod(e.target.value)}>{["cash","upi","bank_transfer","cheque","card","other"].map(x=><option key={x} value={x}>{x.replace("_"," ")}</option>)}</select></div>
 <div className="field"><label>Amount (₹)</label><input type="number" min="0.01" step="0.01" required value={amount} onChange={e=>setAmount(e.target.value)}/></div>
 <div className="field"><label>Transaction date</label><input type="date" required value={date} onChange={e=>setDate(e.target.value)}/></div>
 <div className="field"><label>Client ID (optional UUID)</label><input value={clientId} onChange={e=>setClientId(e.target.value)} placeholder="Client record ID"/></div>
 <div className="field"><label>Vendor ID (optional UUID)</label><input value={vendorId} onChange={e=>setVendorId(e.target.value)} placeholder="Vendor record ID"/></div>
 {method!=="cash"&&<div className="field"><label>Bank account</label><select required value={bankId} onChange={e=>setBankId(e.target.value)}><option value="">Select configured bank account</option>{banks.map(b=><option key={b.id} value={b.id}>{b.account_name}{b.bank_name?` · ${b.bank_name}`:""}</option>)}</select></div>}
 {direction==="out"&&<div className="field"><label>Expense / liability account code</label><input required value={counter} onChange={e=>setCounter(e.target.value)} placeholder="Choose valid account code e.g. expense ledger"/></div>}
 <div className="field"><label>UPI / bank reference</label><input value={reference} onChange={e=>setReference(e.target.value)}/></div>
 <div className="field wide"><label>Notes</label><textarea value={notes} onChange={e=>setNotes(e.target.value)}/></div>
 </div>{error&&<p className="error">{error}</p>}{message&&<p className="success">{message}</p>}<button className="btn" disabled={busy}>{busy?"Saving…":"Record transaction"}</button></form>
 <p className="sub" style={{marginTop:15}}>Invoice allocation is not yet exposed in this starter form. Incoming receipts are currently recorded as customer advances unless allocations are supplied through the backend RPC.</p>
 </main>;
}