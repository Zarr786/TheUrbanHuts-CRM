import { createClient } from "@/lib/supabase/server";
export default async function LedgerPage(){
 const s=await createClient();
 const [{data:accounts,error:aerr},{data:entries,error:eerr}]=await Promise.all([
 s.from("ledger_accounts").select("id,code,name,account_type,active").order("code").limit(100),
 s.from("journal_entries").select("id,entry_number,entry_date,description,status").order("entry_date",{ascending:false}).limit(30)
 ]);
 return <main className="content"><div className="eyebrow">Finance</div><h1 className="heading">Ledger & cashbook</h1><p className="sub">Chart of accounts and latest journal entries.</p>
 <div className="panel"><h2>Chart of accounts</h2>{aerr?<p className="error">{aerr.message}</p>:<div className="tablewrap"><table><thead><tr><th>Code</th><th>Account</th><th>Type</th><th>Status</th></tr></thead><tbody>{(accounts??[]).map((x:any)=><tr key={x.id}><td>{x.code}</td><td>{x.name}</td><td>{x.account_type}</td><td>{x.active?"Active":"Inactive"}</td></tr>)}</tbody></table></div>}</div>
 <div className="panel"><h2>Latest journal entries <span className="muted">(up to 30)</span></h2>{eerr?<p className="error">{eerr.message}</p>:<div className="tablewrap"><table><thead><tr><th>Entry no.</th><th>Date</th><th>Description</th><th>Status</th></tr></thead><tbody>{(entries??[]).map((x:any)=><tr key={x.id}><td>{x.entry_number}</td><td>{x.entry_date}</td><td>{x.description}</td><td>{x.status}</td></tr>)}</tbody></table></div>}</div>
 </main>;
}